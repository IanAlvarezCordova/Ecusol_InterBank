package com.ecusol.ms_transacciones.controller;

import com.ecusol.ms_transacciones.dto.SwitchTransaccionWrapper;
import com.ecusol.ms_transacciones.service.TransaccionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transacciones")
@RequiredArgsConstructor
@Tag(name = "Switch Webhook")
public class TransaccionInterbancariaController {

    private final TransaccionService service;

    @Operation(summary = "Recibir pago externo")
    @PostMapping("/webhook")
    public ResponseEntity<Void> recibir(@Valid @RequestBody SwitchTransaccionWrapper wrapper) {
        service.procesarPagoEntrante(wrapper.getTransaccion());
        return ResponseEntity.ok().build();
    }
}
