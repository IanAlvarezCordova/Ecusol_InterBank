package com.ecusol.ms_transacciones.client;

import com.ecusol.ms_transacciones.dto.SwitchTransaccionWrapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class SwitchClient {

    private final RestTemplate restTemplate;

    @org.springframework.beans.factory.annotation.Value("${api.switch.url}")
    private String urlSwitch;

    public void enviar(SwitchTransaccionWrapper request) {
        // Si falla, el RestTemplate lanza excepción y activa el Catch del SAGA
        restTemplate.postForEntity(urlSwitch, request, Void.class);
    }
}
