package com.cuentas.productos.cbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
